# JsScratch

JsScratch is a project player in JavaScript and HTML for MIT Scratch.